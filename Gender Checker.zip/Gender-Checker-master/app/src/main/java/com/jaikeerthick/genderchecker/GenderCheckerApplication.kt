package com.jaikeerthick.genderchecker

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class GenderCheckerApplication: Application()