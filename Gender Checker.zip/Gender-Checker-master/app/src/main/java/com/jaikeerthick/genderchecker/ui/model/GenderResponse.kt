package com.jaikeerthick.genderchecker.ui.model

data class GenderResponse(
    val name: String?,
    val gender: String?,
    val probability: Float?
)
